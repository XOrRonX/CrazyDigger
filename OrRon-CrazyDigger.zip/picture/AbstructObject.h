#pragma once
class AbstructObject {};

